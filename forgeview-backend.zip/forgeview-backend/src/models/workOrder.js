import { v4 as uuid } from "uuid";
import { query, withTransaction } from "../db/pool.js";

// Status order mirrors STATUS_STEPS in the frontend prototype exactly,
// so the dashboard track and the DB enum never drift apart.
export const STATUS_ORDER = [
  "received",
  "in_review",
  "modeling",
  "rendering",
  "ready",
];

let orderCounter = 2291; // seed to match the prototype's sample data

function nextOrderNumber() {
  orderCounter += 1;
  return `WO-${orderCounter}`;
}

/**
 * Create a work order + its station_jobs (one per selected package) in a
 * single transaction, and stamp the traveler card with 'received'.
 */
export async function createWorkOrder({ companyId, productName, material, dimensions, notes, packages }) {
  return withTransaction(async (client) => {
    const orderNumber = nextOrderNumber();

    const woResult = await client.query(
      `INSERT INTO work_orders (order_number, company_id, product_name, material, dimensions, notes, status)
       VALUES ($1, $2, $3, $4, $5, $6, 'received')
       RETURNING *`,
      [orderNumber, companyId, productName, material, dimensions, notes]
    );
    const workOrder = woResult.rows[0];

    for (const pkg of packages) {
      await client.query(
        `INSERT INTO station_jobs (work_order_id, package_type, status)
         VALUES ($1, $2, 'queued')`,
        [workOrder.id, pkg]
      );
    }

    await client.query(
      `INSERT INTO routing_log (work_order_id, stamp, detail)
       VALUES ($1, 'received', $2)`,
      [workOrder.id, `Order opened with ${packages.length} package(s): ${packages.join(", ")}`]
    );

    return workOrder;
  });
}

/**
 * Move a work order to a new status and stamp the traveler card.
 * This is the single place status ever changes — workers and routes
 * both call through here so the log can never be skipped.
 */
export async function stampWorkOrder({ workOrderId, status, stamp, detail, stationJobId = null }) {
  return withTransaction(async (client) => {
    if (status) {
      await client.query(
        `UPDATE work_orders SET status = $1, updated_at = now() WHERE id = $2`,
        [status, workOrderId]
      );
    }
    await client.query(
      `INSERT INTO routing_log (work_order_id, station_job_id, stamp, detail)
       VALUES ($1, $2, $3, $4)`,
      [workOrderId, stationJobId, stamp, detail || null]
    );
  });
}

export async function getWorkOrder(id) {
  const wo = await query(`SELECT * FROM work_orders WHERE id = $1`, [id]);
  if (wo.rows.length === 0) return null;

  const [jobs, assets, log] = await Promise.all([
    query(`SELECT * FROM station_jobs WHERE work_order_id = $1 ORDER BY queued_at`, [id]),
    query(`SELECT * FROM assets WHERE work_order_id = $1 ORDER BY created_at`, [id]),
    query(`SELECT * FROM routing_log WHERE work_order_id = $1 ORDER BY created_at`, [id]),
  ]);

  return {
    ...wo.rows[0],
    stationJobs: jobs.rows,
    assets: assets.rows,
    routingLog: log.rows,
  };
}

export async function listWorkOrders({ companyId } = {}) {
  const text = companyId
    ? `SELECT * FROM work_orders WHERE company_id = $1 ORDER BY created_at DESC`
    : `SELECT * FROM work_orders ORDER BY created_at DESC`;
  const params = companyId ? [companyId] : [];
  const res = await query(text, params);
  return res.rows;
}

/**
 * Re-derive the parent work order's overall status from its station_jobs.
 * Called after any station_job completes/fails. Keeps the "headline" status
 * (what the dashboard track shows) consistent with the detailed job states,
 * without the workers needing to know the full state machine themselves.
 */
export async function recomputeWorkOrderStatus(workOrderId) {
  const jobsRes = await query(
    `SELECT package_type, status FROM station_jobs WHERE work_order_id = $1`,
    [workOrderId]
  );
  const jobs = jobsRes.rows;

  let nextStatus;
  if (jobs.some((j) => j.status === "failed")) {
    nextStatus = "on_hold";
  } else if (jobs.every((j) => j.status === "complete")) {
    nextStatus = "ready";
  } else if (jobs.some((j) => j.package_type === "renders" && j.status !== "queued")) {
    nextStatus = "rendering";
  } else if (jobs.some((j) => j.package_type === "model3d" && j.status !== "queued")) {
    nextStatus = "modeling";
  } else {
    nextStatus = "in_review";
  }

  await stampWorkOrder({
    workOrderId,
    status: nextStatus,
    stamp: `auto_routed_to_${nextStatus}`,
    detail: "Recomputed from station job states",
  });

  return nextStatus;
}
