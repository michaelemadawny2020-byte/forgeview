import { QUEUE_NAMES } from "../queue/queues.js";
import { createStationWorker } from "./stationWorkerFactory.js";
import { submitVideoGeneration, pollVideoGeneration } from "../services/videoService.js";

export const aiVideoWorker = createStationWorker(
  QUEUE_NAMES.aivideo,
  "aivideo",
  async ({ workOrderId, heroImageUrl, productName }) => {
    const prompt = `Slow rotating product shot of ${productName}, studio lighting, subtle camera push-in`;
    const { providerJobId, provider } = await submitVideoGeneration({
      imageUrl: heroImageUrl,
      prompt,
      durationSeconds: 20,
    });
    const result = await pollVideoGeneration(providerJobId);

    return [
      {
        assetType: "video",
        storageKey: `work-orders/${workOrderId}/ai_product_film.mp4`,
        publicUrl: result.videoUrl,
        metadata: { provider, providerJobId, durationSeconds: result.durationSeconds, prompt },
      },
    ];
  }
);
