import express from "express";
import { z } from "zod";
import { query } from "../db/pool.js";

export const companyRouter = express.Router();

const createSchema = z.object({
  name: z.string().min(1),
  contactEmail: z.string().email(),
});

companyRouter.post("/", async (req, res, next) => {
  try {
    const input = createSchema.parse(req.body);
    const result = await query(
      `INSERT INTO companies (name, contact_email) VALUES ($1, $2) RETURNING *`,
      [input.name, input.contactEmail]
    );
    res.status(201).json({ company: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

companyRouter.get("/", async (req, res, next) => {
  try {
    const result = await query(`SELECT * FROM companies ORDER BY created_at DESC`);
    res.json({ companies: result.rows });
  } catch (err) {
    next(err);
  }
});
