import { QUEUE_NAMES } from "../queue/queues.js";
import { createStationWorker } from "./stationWorkerFactory.js";
import { generateRenderSet, pollRenderSet } from "../services/renderService.js";

// Turntable reuses the render service (it's a rotation render, not generative
// video) but is its own queue/package so it can be priced, scheduled, and
// retried independently of the still-image render set.
export const turntableWorker = createStationWorker(
  QUEUE_NAMES.turntable,
  "turntable",
  async ({ workOrderId, modelUrl }) => {
    const { providerJobId } = await generateRenderSet({ modelUrl, angles: 36, style: "turntable" });
    await pollRenderSet(providerJobId, 36); // would actually return a stitched video, stubbed simply here

    return [
      {
        assetType: "video",
        storageKey: `work-orders/${workOrderId}/turntable.mp4`,
        publicUrl: `https://assets.forgeview.example/stub/${providerJobId}_turntable.mp4`,
        metadata: { providerJobId, loop: true },
      },
    ];
  }
);
