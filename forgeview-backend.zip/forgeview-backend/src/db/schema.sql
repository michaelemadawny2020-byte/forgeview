-- Forgeview schema
-- Philosophy: a work_order is a physical-paperwork analogue. It doesn't just have
-- a "status" field — it has a routing_log (traveler card) of every stamp it received,
-- and each requested package becomes a "station_job" that moves through the line
-- independently, so a render can be done while the video is still in queue.

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TYPE work_order_status AS ENUM (
  'received',
  'in_review',
  'modeling',
  'rendering',
  'ready',
  'on_hold',
  'rejected'
);

CREATE TYPE package_type AS ENUM (
  'model3d',
  'renders',
  'turntable',
  'aivideo',
  'variants'
);

CREATE TYPE station_job_status AS ENUM (
  'queued',
  'in_progress',
  'needs_review',
  'complete',
  'failed'
);

-- Companies submitting work
CREATE TABLE companies (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  contact_email TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- The work order itself — one per product submission
CREATE TABLE work_orders (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_number TEXT NOT NULL UNIQUE,        -- human-facing, e.g. "WO-2291"
  company_id UUID NOT NULL REFERENCES companies(id),
  product_name TEXT NOT NULL,
  material TEXT,
  dimensions TEXT,
  notes TEXT,
  status work_order_status NOT NULL DEFAULT 'received',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Raw uploads attached to a work order (source photos, CAD, spec sheets)
CREATE TABLE source_files (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  work_order_id UUID NOT NULL REFERENCES work_orders(id) ON DELETE CASCADE,
  storage_key TEXT NOT NULL,          -- key in object storage
  original_filename TEXT NOT NULL,
  content_type TEXT,
  byte_size INTEGER,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- One row per package selected on the work order. This is the unit of work
-- that actually moves through a queue/station.
CREATE TABLE station_jobs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  work_order_id UUID NOT NULL REFERENCES work_orders(id) ON DELETE CASCADE,
  package_type package_type NOT NULL,
  status station_job_status NOT NULL DEFAULT 'queued',
  provider TEXT,                      -- e.g. 'meshy', 'runway', 'local-render'
  provider_job_id TEXT,               -- external job/task id for polling or webhook matching
  input_payload JSONB,                -- what we sent the provider
  output_payload JSONB,               -- what the provider returned (asset urls, metadata)
  error_message TEXT,
  attempts INTEGER NOT NULL DEFAULT 0,
  queued_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  started_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ
);

-- Finished, downloadable assets — decoupled from station_jobs so a job can
-- produce multiple assets (e.g. renders = 8 images from one job)
CREATE TABLE assets (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  work_order_id UUID NOT NULL REFERENCES work_orders(id) ON DELETE CASCADE,
  station_job_id UUID REFERENCES station_jobs(id) ON DELETE SET NULL,
  asset_type TEXT NOT NULL,           -- 'glb', 'render_image', 'video'
  storage_key TEXT NOT NULL,
  public_url TEXT,
  metadata JSONB,                     -- dims, duration, angle label, variant name, etc
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- The "traveler card": an append-only log of every status stamp a work order
-- receives. This is the audit trail and what powers the routing-slip UI track.
CREATE TABLE routing_log (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  work_order_id UUID NOT NULL REFERENCES work_orders(id) ON DELETE CASCADE,
  station_job_id UUID REFERENCES station_jobs(id) ON DELETE SET NULL,
  stamp TEXT NOT NULL,                -- e.g. 'received', 'routed_to_modeling', 'meshy_failed'
  detail TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_station_jobs_work_order ON station_jobs(work_order_id);
CREATE INDEX idx_station_jobs_status ON station_jobs(status);
CREATE INDEX idx_assets_work_order ON assets(work_order_id);
CREATE INDEX idx_routing_log_work_order ON routing_log(work_order_id);
