import "dotenv/config";

/**
 * Render station — produces the photoreal angle set from a GLB.
 * RENDER_SERVICE_MODE picks between a local headless renderer (Blender/
 * three.js on a worker box) and a hosted model via Replicate. Stubbed here
 * either way; swap in real calls behind the same interface.
 */
export async function generateRenderSet({ modelUrl, angles = 8, style = "studio" }) {
  const mode = process.env.RENDER_SERVICE_MODE || "local";
  console.log(`[render:stub:${mode}] generating ${angles} ${style} renders from ${modelUrl}`);

  if (mode === "replicate") {
    // --- Real call would look like this ---
    // const res = await fetch("https://api.replicate.com/v1/predictions", {
    //   method: "POST",
    //   headers: {
    //     Authorization: `Token ${process.env.REPLICATE_API_KEY}`,
    //     "Content-Type": "application/json",
    //   },
    //   body: JSON.stringify({
    //     version: "<sdxl-or-render-model-version>",
    //     input: { image: modelUrl, style },
    //   }),
    // });
    // const data = await res.json();
    // return { providerJobId: data.id };
  }

  // --- Local mode would shell out to a headless Blender/three.js script ---
  // const { providerJobId } = await spawnLocalRenderJob({ modelUrl, angles, style });

  const fakeJobId = `render_${Math.random().toString(36).slice(2, 10)}`;
  return { providerJobId: fakeJobId };
}

export async function pollRenderSet(providerJobId, angles = 8) {
  console.log(`[render:stub] polling ${providerJobId}`);

  // Stub: pretend it's complete, return N placeholder image URLs.
  const imageUrls = Array.from({ length: angles }, (_, i) =>
    `https://assets.forgeview.example/stub/${providerJobId}_angle${i + 1}.jpg`
  );

  return { status: "complete", imageUrls };
}
