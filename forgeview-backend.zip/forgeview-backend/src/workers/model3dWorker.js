import { QUEUE_NAMES, enqueueStationJob } from "../queue/queues.js";
import { createStationWorker } from "./stationWorkerFactory.js";
import { submitImageTo3D, pollImageTo3D } from "../services/meshyService.js";
import { query } from "../db/pool.js";

/**
 * Once a GLB exists, any other queued station that depends on it (renders,
 * turntable, variants) can move from queued -> dispatched. aivideo depends
 * on a hero render rather than the raw model, so it's chained separately
 * from the renders worker, not from here.
 */
async function chainDownstreamStations(workOrderId, modelUrl, productName) {
  const dependents = await query(
    `SELECT id, package_type FROM station_jobs
     WHERE work_order_id = $1 AND package_type IN ('renders', 'turntable', 'variants') AND status = 'queued'`,
    [workOrderId]
  );

  for (const job of dependents.rows) {
    await enqueueStationJob(job.package_type, {
      workOrderId,
      stationJobId: job.id,
      modelUrl,
      productName,
    });
  }
}

export const model3dWorker = createStationWorker(
  QUEUE_NAMES.model3d,
  "model3d",
  async ({ workOrderId, imageUrls, productName }) => {
    const { providerJobId } = await submitImageTo3D({ imageUrls, productName });

    // In production this would be a webhook-driven wait, not a blocking poll.
    // Kept synchronous here so the stub flow is easy to read end-to-end.
    const result = await pollImageTo3D(providerJobId);

    await chainDownstreamStations(workOrderId, result.modelUrl, productName);

    return [
      {
        assetType: "glb",
        storageKey: `work-orders/${workOrderId}/model.glb`,
        publicUrl: result.modelUrl,
        metadata: { provider: "meshy", providerJobId },
      },
    ];
  }
);
