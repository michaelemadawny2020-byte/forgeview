import { QUEUE_NAMES, enqueueStationJob } from "../queue/queues.js";
import { createStationWorker } from "./stationWorkerFactory.js";
import { generateRenderSet, pollRenderSet } from "../services/renderService.js";
import { query } from "../db/pool.js";

async function chainAiVideo(workOrderId, heroImageUrl, productName) {
  const dependent = await query(
    `SELECT id FROM station_jobs WHERE work_order_id = $1 AND package_type = 'aivideo' AND status = 'queued'`,
    [workOrderId]
  );
  if (dependent.rows.length === 0) return;

  await enqueueStationJob("aivideo", {
    workOrderId,
    stationJobId: dependent.rows[0].id,
    heroImageUrl,
    productName,
  });
}

export const rendersWorker = createStationWorker(
  QUEUE_NAMES.renders,
  "renders",
  async ({ workOrderId, modelUrl, productName }) => {
    const { providerJobId } = await generateRenderSet({ modelUrl, angles: 8 });
    const result = await pollRenderSet(providerJobId, 8);

    await chainAiVideo(workOrderId, result.imageUrls[0], productName);

    return result.imageUrls.map((url, i) => ({
      assetType: "render_image",
      storageKey: `work-orders/${workOrderId}/renders/angle_${i + 1}.jpg`,
      publicUrl: url,
      metadata: { angle: i + 1, providerJobId },
    }));
  }
);
