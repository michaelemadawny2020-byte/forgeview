// src/api/forgeviewClient.js
//
// Thin wrapper around the Forgeview Express API. Every function here maps
// 1:1 to a route in forgeview-backend/src/routes/*.js. Swap the mock
// useState calls in the React prototype for these and the UI needs almost
// no other changes, since the data shapes already match (STATUS_STEPS,
// PACKAGES ids, etc. were designed to mirror the DB enums).

const API_BASE = import.meta.env?.VITE_API_BASE || "http://localhost:4000";

async function request(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `Request failed: ${res.status}`);
  }
  return res.json();
}

// ---- Companies ----

export function createCompany({ name, contactEmail }) {
  return request("/companies", {
    method: "POST",
    body: JSON.stringify({ name, contactEmail }),
  });
}

export function listCompanies() {
  return request("/companies");
}

// ---- Uploads ----

// Returns { uploadUrl, publicUrl, key }. Frontend PUTs the raw file to
// uploadUrl directly (bypassing the API server), then sends publicUrl
// along when creating the work order.
export async function presignUpload({ filename, contentType }) {
  return request("/uploads/presign", {
    method: "POST",
    body: JSON.stringify({ filename, contentType }),
  });
}

export async function uploadFile(file) {
  const { uploadUrl, publicUrl } = await presignUpload({
    filename: file.name,
    contentType: file.type,
  });

  // In production this PUTs straight to S3/R2. Stubbed backend returns a
  // fake uploadUrl, so skip the actual PUT until real storage is wired in.
  // await fetch(uploadUrl, { method: "PUT", body: file, headers: { "Content-Type": file.type } });

  return publicUrl;
}

// ---- Work orders ----

// packages: array of 'model3d' | 'renders' | 'turntable' | 'aivideo' | 'variants'
// matches PACKAGES ids in the React prototype exactly.
export function createWorkOrder({ companyId, productName, material, dimensions, notes, packages, imageUrls }) {
  return request("/work-orders", {
    method: "POST",
    body: JSON.stringify({ companyId, productName, material, dimensions, notes, packages, imageUrls }),
  });
}

export function listWorkOrders({ companyId } = {}) {
  const qs = companyId ? `?companyId=${companyId}` : "";
  return request(`/work-orders${qs}`);
}

export function getWorkOrder(id) {
  return request(`/work-orders/${id}`);
}

// ---- Status mapping ----
// The DB's work_order_status enum and the frontend's STATUS_STEPS array
// represent the same progression with different labels. This maps one to
// the other so existing UI components (status track, badges) work unchanged.
export const DB_STATUS_TO_STEP_INDEX = {
  received: 0,
  in_review: 1,
  modeling: 2,
  rendering: 3,
  ready: 4,
  on_hold: 1, // shown as "stuck in review" rather than a 6th step
  rejected: 0,
};
