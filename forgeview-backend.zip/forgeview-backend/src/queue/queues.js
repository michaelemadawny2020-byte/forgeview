import { Queue } from "bullmq";
import IORedis from "ioredis";
import "dotenv/config";

export const connection = new IORedis(process.env.REDIS_URL, {
  maxRetriesPerRequest: null, // required by BullMQ
});

// One queue per station on the line. Each package type a customer can order
// maps 1:1 to a queue, so scaling/monitoring/retrying one station never
// touches the others — e.g. the video station can be slow without backing
// up 3D modeling.
export const QUEUE_NAMES = {
  model3d: "station:model3d",
  renders: "station:renders",
  turntable: "station:turntable",
  aivideo: "station:aivideo",
  variants: "station:variants",
};

const defaultJobOptions = {
  attempts: 3,
  backoff: { type: "exponential", delay: 15_000 },
  removeOnComplete: { age: 60 * 60 * 24 * 7 }, // keep 7 days for the routing log / debugging
  removeOnFail: false, // keep failed jobs visible — a failed job is a "hold" on the order
};

export const queues = Object.fromEntries(
  Object.entries(QUEUE_NAMES).map(([pkg, name]) => [
    pkg,
    new Queue(name, { connection, defaultJobOptions }),
  ])
);

/**
 * Enqueue a station_job for processing. jobData always carries the
 * work order id, station job id, and whatever input the provider needs,
 * so workers are stateless and re-readable from the job payload alone.
 */
export async function enqueueStationJob(packageType, jobData) {
  const queue = queues[packageType];
  if (!queue) throw new Error(`No queue configured for package type: ${packageType}`);
  return queue.add(packageType, jobData);
}
