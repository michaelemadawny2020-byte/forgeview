import express from "express";
import { v4 as uuid } from "uuid";
import "dotenv/config";

export const uploadRouter = express.Router();

/**
 * POST /uploads/presign — returns a presigned PUT URL so the frontend can
 * upload source photos/CAD directly to object storage, instead of routing
 * large binaries through the API server.
 *
 * Stubbed: returns a fake-but-correctly-shaped response. Real implementation
 * uses @aws-sdk/s3-request-presigner against STORAGE_* env vars.
 */
uploadRouter.post("/presign", async (req, res, next) => {
  try {
    const { filename, contentType } = req.body;
    if (!filename) return res.status(400).json({ error: "filename is required" });

    const key = `uploads/${uuid()}-${filename}`;

    // --- Real implementation ---
    // import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
    // import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
    // const s3 = new S3Client({ region: process.env.STORAGE_REGION, endpoint: process.env.STORAGE_ENDPOINT, ... });
    // const command = new PutObjectCommand({ Bucket: process.env.STORAGE_BUCKET, Key: key, ContentType: contentType });
    // const uploadUrl = await getSignedUrl(s3, command, { expiresIn: 300 });

    const uploadUrl = `https://stub-upload.forgeview.example/${key}?signature=stub`;
    const publicUrl = `${process.env.STORAGE_PUBLIC_BASE_URL || "https://assets.forgeview.example"}/${key}`;

    res.json({ uploadUrl, publicUrl, key });
  } catch (err) {
    next(err);
  }
});
