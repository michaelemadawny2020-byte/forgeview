import express from "express";
import { workOrderRouter } from "./routes/workOrders.js";
import { companyRouter } from "./routes/companies.js";
import { uploadRouter } from "./routes/uploads.js";
import { webhookRouter } from "./routes/webhooks.js";

export const app = express();

app.use(express.json());

app.get("/health", (req, res) => res.json({ status: "ok", shop: "forgeview" }));

app.use("/work-orders", workOrderRouter);
app.use("/companies", companyRouter);
app.use("/uploads", uploadRouter);
app.use("/webhooks", webhookRouter);

// Centralized error handler — Zod validation errors and thrown errors
// both land here so routes can stay focused on the happy path.
app.use((err, req, res, next) => {
  if (err.name === "ZodError") {
    return res.status(400).json({ error: "Validation failed", details: err.errors });
  }
  console.error("[error]", err);
  res.status(500).json({ error: "Internal error" });
});
