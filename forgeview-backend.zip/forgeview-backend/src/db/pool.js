import pg from "pg";
import "dotenv/config";

export const pool = new pg.Pool({
  connectionString: process.env.DATABASE_URL,
});

pool.on("error", (err) => {
  console.error("[db] unexpected error on idle client", err);
});

export async function query(text, params) {
  const start = Date.now();
  const res = await pool.query(text, params);
  const ms = Date.now() - start;
  if (process.env.NODE_ENV === "development") {
    console.log(`[db] ${text.split("\n")[0].slice(0, 80)} (${ms}ms, ${res.rowCount} rows)`);
  }
  return res;
}

// Run multiple queries inside a transaction. Used anywhere we touch
// work_orders + routing_log together, so a stamp is never recorded
// without the status change actually committing (and vice versa).
export async function withTransaction(fn) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const result = await fn(client);
    await client.query("COMMIT");
    return result;
  } catch (err) {
    await client.query("ROLLBACK");
    throw err;
  } finally {
    client.release();
  }
}
