import "dotenv/config";
import { model3dWorker } from "./model3dWorker.js";
import { rendersWorker } from "./rendersWorker.js";
import { turntableWorker } from "./turntableWorker.js";
import { aiVideoWorker } from "./aiVideoWorker.js";
import { variantsWorker } from "./variantsWorker.js";

const workers = [model3dWorker, rendersWorker, turntableWorker, aiVideoWorker, variantsWorker];

workers.forEach((w) => {
  w.on("completed", (job) => console.log(`[worker:${w.name}] completed job ${job.id}`));
  w.on("failed", (job, err) => console.error(`[worker:${w.name}] failed job ${job?.id}:`, err.message));
});

console.log(`[workers] ${workers.length} station(s) online: ${workers.map((w) => w.name).join(", ")}`);

process.on("SIGTERM", async () => {
  console.log("[workers] shutting down...");
  await Promise.all(workers.map((w) => w.close()));
  process.exit(0);
});
