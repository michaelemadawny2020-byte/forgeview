import express from "express";
import crypto from "crypto";
import "dotenv/config";

export const webhookRouter = express.Router();

/**
 * Verifies an inbound webhook signature against WEBHOOK_SIGNING_SECRET.
 * Each provider has its own signing scheme in reality (Runway, Meshy, etc
 * differ) — this is a generic HMAC stand-in to show where that check goes.
 */
function verifySignature(rawBody, signatureHeader) {
  if (!process.env.WEBHOOK_SIGNING_SECRET || process.env.WEBHOOK_SIGNING_SECRET === "changeme") {
    console.warn("[webhooks] signing secret not configured — skipping verification (dev only)");
    return true;
  }
  const expected = crypto
    .createHmac("sha256", process.env.WEBHOOK_SIGNING_SECRET)
    .update(rawBody)
    .digest("hex");
  return signatureHeader === expected;
}

// POST /webhooks/meshy — Meshy calls back here when an image-to-3d task finishes.
// Stubbed: in the current flow we poll synchronously inside the worker, so this
// route exists as the intended production path once polling is swapped out.
webhookRouter.post("/meshy", express.raw({ type: "*/*" }), async (req, res) => {
  const signature = req.headers["x-meshy-signature"];
  if (!verifySignature(req.body, signature)) {
    return res.status(401).json({ error: "Invalid signature" });
  }

  const payload = JSON.parse(req.body.toString("utf8"));
  console.log("[webhooks:meshy] received", payload);

  // TODO: look up station_job by provider_job_id, mark complete/failed,
  // insert asset row, call recomputeWorkOrderStatus — same as the worker does.
  res.status(200).json({ received: true });
});

// POST /webhooks/runway — same idea for the AI video provider.
webhookRouter.post("/runway", express.raw({ type: "*/*" }), async (req, res) => {
  const signature = req.headers["x-runway-signature"];
  if (!verifySignature(req.body, signature)) {
    return res.status(401).json({ error: "Invalid signature" });
  }

  const payload = JSON.parse(req.body.toString("utf8"));
  console.log("[webhooks:runway] received", payload);

  res.status(200).json({ received: true });
});
