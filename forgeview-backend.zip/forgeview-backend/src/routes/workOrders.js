import express from "express";
import { z } from "zod";
import {
  createWorkOrder,
  getWorkOrder,
  listWorkOrders,
} from "../models/workOrder.js";
import { enqueueStationJob } from "../queue/queues.js";
import { query } from "../db/pool.js";

export const workOrderRouter = express.Router();

const createSchema = z.object({
  companyId: z.string().uuid(),
  productName: z.string().min(1),
  material: z.string().optional(),
  dimensions: z.string().optional(),
  notes: z.string().optional(),
  packages: z
    .array(z.enum(["model3d", "renders", "turntable", "aivideo", "variants"]))
    .min(1, "Select at least one package"),
  imageUrls: z.array(z.string().url()).default([]), // uploaded source photos, already in storage
});

// POST /work-orders — open a new routing slip and queue its first station(s)
workOrderRouter.post("/", async (req, res, next) => {
  try {
    const input = createSchema.parse(req.body);

    const workOrder = await createWorkOrder({
      companyId: input.companyId,
      productName: input.productName,
      material: input.material,
      dimensions: input.dimensions,
      notes: input.notes,
      packages: input.packages,
    });

    // model3d is the entry station for any order that needs it — renders/
    // turntable/variants all depend on a GLB, so they queue once model3d
    // completes (see webhook/worker chaining below), not immediately here.
    const stationJobsRes = await query(
      `SELECT id, package_type FROM station_jobs WHERE work_order_id = $1`,
      [workOrder.id]
    );

    const needsModel = input.packages.includes("model3d");
    if (needsModel) {
      const modelJob = stationJobsRes.rows.find((j) => j.package_type === "model3d");
      await enqueueStationJob("model3d", {
        workOrderId: workOrder.id,
        stationJobId: modelJob.id,
        imageUrls: input.imageUrls,
        productName: input.productName,
      });
    } else {
      // Edge case: customer ordered renders/video without a model job —
      // assume they're supplying a model separately; for the prototype we
      // just log it as needing manual routing rather than guessing an input.
      console.warn(`[work-orders] ${workOrder.order_number} has no model3d package; downstream stations will need manual input wiring`);
    }

    res.status(201).json({ workOrder, stationJobs: stationJobsRes.rows });
  } catch (err) {
    next(err);
  }
});

// GET /work-orders — dashboard list
workOrderRouter.get("/", async (req, res, next) => {
  try {
    const { companyId } = req.query;
    const orders = await listWorkOrders({ companyId });
    res.json({ workOrders: orders });
  } catch (err) {
    next(err);
  }
});

// GET /work-orders/:id — project detail, including station jobs, assets, routing log
workOrderRouter.get("/:id", async (req, res, next) => {
  try {
    const workOrder = await getWorkOrder(req.params.id);
    if (!workOrder) return res.status(404).json({ error: "Work order not found" });
    res.json({ workOrder });
  } catch (err) {
    next(err);
  }
});
