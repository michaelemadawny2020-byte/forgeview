import "dotenv/config";

/**
 * Meshy station — turns source photos into a GLB.
 * Stubbed: returns a fake task id immediately and resolves with a fake
 * asset after a short delay, mimicking Meshy's async image-to-3d flow.
 *
 * Real implementation would:
 *   POST {MESHY_API_BASE}/image-to-3d  { image_urls, ... } -> { result: task_id }
 *   then either poll GET /image-to-3d/{task_id} or receive a webhook
 *   pointing back at /webhooks/meshy
 */
export async function submitImageTo3D({ imageUrls, productName }) {
  console.log(`[meshy:stub] submitting ${imageUrls.length} image(s) for "${productName}"`);

  // --- Real call would look like this ---
  // const res = await fetch(`${process.env.MESHY_API_BASE}/image-to-3d`, {
  //   method: "POST",
  //   headers: {
  //     Authorization: `Bearer ${process.env.MESHY_API_KEY}`,
  //     "Content-Type": "application/json",
  //   },
  //   body: JSON.stringify({ image_urls: imageUrls, enable_pbr: true }),
  // });
  // const data = await res.json();
  // return { providerJobId: data.result };

  const fakeTaskId = `meshy_${Math.random().toString(36).slice(2, 10)}`;
  return { providerJobId: fakeTaskId };
}

export async function pollImageTo3D(providerJobId) {
  console.log(`[meshy:stub] polling ${providerJobId}`);

  // --- Real call ---
  // const res = await fetch(`${process.env.MESHY_API_BASE}/image-to-3d/${providerJobId}`, {
  //   headers: { Authorization: `Bearer ${process.env.MESHY_API_KEY}` },
  // });
  // const data = await res.json();
  // return { status: data.status, modelUrl: data.model_urls?.glb };

  // Stub: pretend it's always immediately done with a placeholder asset URL.
  return {
    status: "complete",
    modelUrl: `https://assets.forgeview.example/stub/${providerJobId}.glb`,
  };
}
