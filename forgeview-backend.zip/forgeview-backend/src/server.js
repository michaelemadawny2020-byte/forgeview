import "dotenv/config";
import { app } from "./app.js";

const port = process.env.PORT || 4000;

app.listen(port, () => {
  console.log(`[forgeview] API listening on :${port}`);
  console.log(`[forgeview] run "npm run worker" in a separate process to bring stations online`);
});
