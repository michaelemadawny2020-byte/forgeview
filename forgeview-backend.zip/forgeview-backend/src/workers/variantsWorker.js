import { QUEUE_NAMES } from "../queue/queues.js";
import { createStationWorker } from "./stationWorkerFactory.js";
import { generateRenderSet, pollRenderSet } from "../services/renderService.js";

export const variantsWorker = createStationWorker(
  QUEUE_NAMES.variants,
  "variants",
  async ({ workOrderId, modelUrl, variantNames = ["Black", "Steel", "White"] }) => {
    const assets = [];

    for (const variantName of variantNames) {
      const { providerJobId } = await generateRenderSet({
        modelUrl,
        angles: 1,
        style: `variant:${variantName}`,
      });
      const result = await pollRenderSet(providerJobId, 1);

      assets.push({
        assetType: "render_image",
        storageKey: `work-orders/${workOrderId}/variants/${variantName.toLowerCase()}.jpg`,
        publicUrl: result.imageUrls[0],
        metadata: { variant: variantName, providerJobId },
      });
    }

    return assets;
  }
);
