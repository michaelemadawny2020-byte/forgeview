import "dotenv/config";

/**
 * Video station — generates the AI product film / turntable motion clip
 * from a rendered hero image. Defaults to Runway, with Luma as an
 * alternate provider behind the same interface (useful for A/B-ing
 * quality/cost, or as a fallback if one provider is degraded).
 */
const PROVIDER = "runway"; // 'runway' | 'luma'

export async function submitVideoGeneration({ imageUrl, prompt, durationSeconds = 20 }) {
  console.log(`[video:stub:${PROVIDER}] generating ${durationSeconds}s clip from ${imageUrl}`);
  console.log(`[video:stub:${PROVIDER}] prompt: "${prompt}"`);

  if (PROVIDER === "runway") {
    // --- Real call ---
    // const res = await fetch(`${process.env.RUNWAY_API_BASE}/image_to_video`, {
    //   method: "POST",
    //   headers: {
    //     Authorization: `Bearer ${process.env.RUNWAY_API_KEY}`,
    //     "Content-Type": "application/json",
    //   },
    //   body: JSON.stringify({ promptImage: imageUrl, promptText: prompt, duration: durationSeconds }),
    // });
    // const data = await res.json();
    // return { providerJobId: data.id, provider: "runway" };
  } else {
    // --- Real call (Luma) ---
    // const res = await fetch(`${process.env.LUMA_API_BASE}/generations`, {
    //   method: "POST",
    //   headers: {
    //     Authorization: `Bearer ${process.env.LUMA_API_KEY}`,
    //     "Content-Type": "application/json",
    //   },
    //   body: JSON.stringify({ image_url: imageUrl, prompt }),
    // });
    // const data = await res.json();
    // return { providerJobId: data.id, provider: "luma" };
  }

  const fakeJobId = `${PROVIDER}_${Math.random().toString(36).slice(2, 10)}`;
  return { providerJobId: fakeJobId, provider: PROVIDER };
}

export async function pollVideoGeneration(providerJobId) {
  console.log(`[video:stub] polling ${providerJobId}`);

  return {
    status: "complete",
    videoUrl: `https://assets.forgeview.example/stub/${providerJobId}.mp4`,
    durationSeconds: 20,
  };
}
