import { Worker } from "bullmq";
import { connection } from "../queue/queues.js";
import { query } from "../db/pool.js";
import { stampWorkOrder, recomputeWorkOrderStatus } from "../models/workOrder.js";

/**
 * Builds a BullMQ Worker for a given station, wiring in the standard
 * traveler-card stamping behavior so every station handles status/logging
 * identically. `process(job)` should return an array of asset rows to insert:
 *   [{ assetType, storageKey, publicUrl, metadata }]
 */
export function createStationWorker(queueName, packageType, process) {
  return new Worker(
    queueName,
    async (job) => {
      const { workOrderId, stationJobId } = job.data;

      await query(
        `UPDATE station_jobs SET status = 'in_progress', started_at = now(), attempts = attempts + 1 WHERE id = $1`,
        [stationJobId]
      );
      await stampWorkOrder({
        workOrderId,
        stamp: `station_${packageType}_started`,
        detail: `Attempt ${job.attemptsMade + 1}`,
        stationJobId,
      });

      try {
        const assets = await process(job.data);

        for (const asset of assets) {
          await query(
            `INSERT INTO assets (work_order_id, station_job_id, asset_type, storage_key, public_url, metadata)
             VALUES ($1, $2, $3, $4, $5, $6)`,
            [workOrderId, stationJobId, asset.assetType, asset.storageKey, asset.publicUrl, asset.metadata || {}]
          );
        }

        await query(
          `UPDATE station_jobs SET status = 'complete', completed_at = now(), output_payload = $2 WHERE id = $1`,
          [stationJobId, JSON.stringify({ assetCount: assets.length })]
        );
        await stampWorkOrder({
          workOrderId,
          stamp: `station_${packageType}_complete`,
          detail: `${assets.length} asset(s) produced`,
          stationJobId,
        });
      } catch (err) {
        await query(
          `UPDATE station_jobs SET status = 'failed', error_message = $2 WHERE id = $1`,
          [stationJobId, err.message]
        );
        await stampWorkOrder({
          workOrderId,
          stamp: `station_${packageType}_failed`,
          detail: err.message,
          stationJobId,
        });
        throw err; // let BullMQ's retry/backoff handle it
      }

      await recomputeWorkOrderStatus(workOrderId);
    },
    { connection, concurrency: 3 }
  );
}
